ALTAR SERVER HUB — WEBSITE FILES

Included:
- index.html: complete responsive website
- Glossary with searchable altar-server terminology
- Customisable altar-server name card with print / Save as PDF
- 10-question quiz with scoring and feedback
- Serving guidance

PREVIEW ON WINDOWS:
1. Extract the ZIP folder.
2. Open the folder.
3. Double-click index.html.
4. It opens in your default browser. The site works locally without installing anything.

FREE HOSTING:
Recommended beginner option: GitHub Pages (free hosting, typically at a github.io address).
1. Visit https://github.com/ and create/sign in to an account.
2. Create a new public repository, for example altar-server-hub.
3. Upload index.html (the file itself should be at the top level of the repository).
4. Open the repository's Settings → Pages.
5. Under build/deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the published URL shown in the Pages section. It will usually look like https://YOUR-USERNAME.github.io/altar-server-hub/
You do not need to buy a custom domain. A custom .com domain usually costs money; the free github.io subdomain is enough to put the website online.
Menu names may change slightly. Keep the repository public for the straightforward free Pages setup.

IMPORTANT:
This ZIP is a website package, not a live website. It becomes public only after you publish it with a hosting service. Ask a trusted adult for help if the hosting account asks for personal or payment details.
