ALTAR SERVER HUB — QUICK START

1. Extract altar_server_hub.zip.
2. Open index.html in a browser to test the site.
3. To publish it, upload index.html to GitHub Pages or another static website host.
4. The glossary search and quiz auto-marking work in the browser.
5. Results are saved only on the same browser/device using local storage.
6. To enable "Send result to creator", open index.html in a text editor and replace:
   creator@example.com
   with the creator's actual email address. The user's device must have an email app/account configured.
7. For automatic collection of results across different devices, connect a shared database or form backend. This ZIP does not include a database, and browser local storage is not global.

The glossary is an educational starter resource. Liturgical practices can vary; follow local parish/diocesan guidance.
